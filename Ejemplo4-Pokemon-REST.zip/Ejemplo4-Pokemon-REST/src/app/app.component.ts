import { PokemonService } from './services/pokemon.service';
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
    pokemons: any[] = [];
    next: string = '';
    previous: string = '';
    nombre: string = '';
    pokemon: any;
    habilitado: boolean = true;

    constructor(private service: PokemonService){
        // Esto no se puede hacer
        // this.pokemons = this.service.getAll();

        // Me subscribo al Observer para estar atenta a recibir las notificaciones
        this.service.getAll().subscribe( (datos) => {
            console.log(datos);
            this.pokemons = datos.results;
            this.next = datos.next;
        } );
    }

    buscar(){
        this.service.buscarPokemon(this.nombre).subscribe( (item) => {
          //console.log(item);
          this.pokemon = item;
        });
    }

    adelante(){
      this.service.emitirPeticion(this.next).subscribe( (datos) => {
        //console.log(datos);
        this.pokemons = datos.results;
        this.next = datos.next;
        this.previous = datos.previous;
        this.habilitado = false;
      });
    }

    atras(){
      this.service.emitirPeticion(this.previous).subscribe( (datos) => {
        //console.log(datos);
        this.pokemons = datos.results;
        this.next = datos.next;
        this.previous = datos.previous;
        if (this.previous == null){
          this.habilitado = true;
        }
      });
    }

}
