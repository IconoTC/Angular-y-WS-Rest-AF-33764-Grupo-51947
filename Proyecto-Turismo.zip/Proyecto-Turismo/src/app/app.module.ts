import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { MuseosComponent } from './components/museos/museos.component';
import { MuseosDetalleComponent } from './components/museos-detalle/museos-detalle.component';
import { RouterModule, Routes } from '@angular/router';
import { NavbarComponent } from './components/navbar/navbar.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { EquipoComponent } from './components/equipo/equipo.component';
import { HomeComponent } from './components/home/home.component';
import { ErrorComponent } from './components/error/error.component';

// Crear el array de rutas
const misRutas: Routes = [
  {path: 'home', component: HomeComponent},
  {path: 'museos', component: MuseosComponent},
  {path: 'detalle/:codigo', component: MuseosDetalleComponent},
  {path: 'equipo', component: EquipoComponent},
  {path: '', redirectTo: 'home', pathMatch: 'full'}, // la ruta debe ser localhost:4200/
  {path: '**', component: ErrorComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    MuseosComponent,
    MuseosDetalleComponent,
    NavbarComponent,
    HeaderComponent,
    FooterComponent,
    EquipoComponent,
    HomeComponent,
    ErrorComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(misRutas),
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
