import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { MuseosComponent } from './components/museos/museos.component';
import { MuseosDetalleComponent } from './components/museos-detalle/museos-detalle.component';
import { RouterModule, Routes } from '@angular/router';
import { NavbarComponent } from './components/navbar/navbar.component';

// Crear el array de rutas
const misRutas: Routes = [
  {path: 'museos', component: MuseosComponent},
  {path: 'detalle/:codigo', component: MuseosDetalleComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    MuseosComponent,
    MuseosDetalleComponent,
    NavbarComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(misRutas)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
