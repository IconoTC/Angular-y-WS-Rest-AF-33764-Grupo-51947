import {Component, Injectable} from '@angular/core';
import {MatPaginatorIntl, MatPaginatorModule} from '@angular/material/paginator';
import {Subject} from 'rxjs';
//import {} from ''

@Injectable()
export class PaginatorService implements MatPaginatorIntl {
  changes = new Subject<void>();

  // Traducir a Español
  firstPageLabel = 'Primera pagina';
  itemsPerPageLabel = 'Mostrar:';
  lastPageLabel = 'Ultima pagina';
  nextPageLabel = 'siguiente';
  previousPageLabel = 'atras';

  
  getRangeLabel(page: number, pageSize: number, length: number): string {
    if (length === 0) {
      return '1 total 1';
    }
    const amountPages = Math.ceil(length / pageSize);
    return 'Page ' + (page + 1) + ' of ' + amountPages;
  }
  
}