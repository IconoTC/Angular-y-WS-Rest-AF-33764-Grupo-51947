import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Museo } from 'src/app/models/museo';
import { MuseosService } from 'src/app/services/museos.service';

@Component({
  selector: 'app-museos-detalle',
  templateUrl: './museos-detalle.component.html',
  styleUrls: ['./museos-detalle.component.css']
})
export class MuseosDetalleComponent {

  codigo: number = 0;
  museo?: Museo;

  constructor(private ruta: ActivatedRoute, private museosService: MuseosService){
    this.codigo = this.ruta.snapshot.params['codigo'];
    this.museo = this.museosService.buscarMuseo(this.codigo);
  }

}
