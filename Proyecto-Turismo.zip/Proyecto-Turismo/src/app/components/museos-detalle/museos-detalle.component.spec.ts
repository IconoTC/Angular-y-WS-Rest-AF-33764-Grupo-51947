import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MuseosDetalleComponent } from './museos-detalle.component';

describe('MuseosDetalleComponent', () => {
  let component: MuseosDetalleComponent;
  let fixture: ComponentFixture<MuseosDetalleComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MuseosDetalleComponent]
    });
    fixture = TestBed.createComponent(MuseosDetalleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
