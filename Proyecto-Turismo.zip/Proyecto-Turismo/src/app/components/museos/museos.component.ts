import { Component } from '@angular/core';
import { Museo } from 'src/app/models/museo';
import { MuseosService } from 'src/app/services/museos.service';

@Component({
  selector: 'app-museos',
  templateUrl: './museos.component.html',
  styleUrls: ['./museos.component.css']
})
export class MuseosComponent {

  museos: Museo[] = [];

  constructor(private museosService: MuseosService){
      this.museos = museosService.getAll();
  }

}
