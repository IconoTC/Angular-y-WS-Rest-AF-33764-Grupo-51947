import { Component } from '@angular/core';

@Component({
  selector: 'app-contacto',
  templateUrl: './contacto.component.html',
  styleUrls: ['./contacto.component.css']
})
export class ContactoComponent {

  nombre: string = '';
  telefono: number = 0;
  email: string = '';
  asunto: string = '';
  mensaje: string = '';
}
