import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  texto: string = "Bienvenidos al curso de Angular";
  numero: number = 267876556.0995454455345;
  porcentaje: number = 0.65432;

  fecha: Date = new Date();

  // La fecha funciona de otras formas pero siempre mes/dia/año
  fecha2: Date = new Date("1/25/2023");
  fecha3: string = "1/25/2023";

  persona: any = {nombre: 'Pepito', apellido: 'Perez', edad: 38,
      telefonos: {tel1: 911234567, tel2: 616987654}};
    
}  
